<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Buku</title>
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
</head>
<body style="background:#f4f6f9">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">📚 Data Buku</h5>
            <a href="<?= site_url('buku/tambah') ?>" class="btn btn-primary btn-sm">
                + Tambah Buku
            </a>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="thead-dark">
                        <tr>
                            <th width="5%">No</th>
                            <th>Judul</th>
                            <th>Pengarang</th>
                            <th>Penerbit</th>
                            <th width="10%">Tahun</th>
                            <th width="8%">Stok</th>
                            <th width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($buku)): ?>
                            <tr>
                                <td colspan="7">Data buku belum ada</td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach($buku as $b): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $b->judul ?></td>
                                <td><?= $b->pengarang ?></td>
                                <td><?= $b->penerbit ?></td>
                                <td><?= $b->tahun ?></td>
                                <td><?= $b->stok ?></td>
                                <td>
                                    <a href="<?= site_url('buku/hapus/'.$b->id) ?>"
                                       onclick="return confirm('Yakin ingin menghapus data ini?')"
                                       class="btn btn-danger btn-sm">
                                       Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card-footer">
            <a href="<?= site_url('dashboard') ?>" class="btn btn-secondary btn-sm">
                ← Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>

</body>
</html>
