<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Buku | Perpustakaan</title>

    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">

    <style>
        body {
            background-color: #f4f6f9;
        }
        .card {
            border-radius: 10px;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-dark bg-dark">
    <span class="navbar-brand mb-0 h1">📚 Perpustakaan Sekolah</span>
    <a href="<?= site_url('buku') ?>" class="btn btn-light btn-sm">
        ← Kembali
    </a>
</nav>

<!-- CONTENT -->
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-7">

            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Tambah Data Buku</h5>
                </div>

                <div class="card-body">
                    <form action="<?= site_url('buku/simpan') ?>" method="post">

                        <div class="form-group">
                            <label>Judul Buku</label>
                            <input type="text" name="judul" class="form-control" placeholder="Masukkan judul buku" required>
                        </div>

                        <div class="form-group">
                            <label>Pengarang</label>
                            <input type="text" name="pengarang" class="form-control" placeholder="Masukkan nama pengarang" required>
                        </div>

                        <div class="form-group">
                            <label>Penerbit</label>
                            <input type="text" name="penerbit" class="form-control" placeholder="Masukkan nama penerbit" required>
                        </div>

                        <div class="form-group">
                            <label>Tahun Terbit</label>
                            <input type="number" name="tahun" class="form-control" placeholder="Contoh: 2024" required>
                        </div>

                        <div class="form-group">
                            <label>Stok Buku</label>
                            <input type="number" name="stok" class="form-control" placeholder="Jumlah stok buku" required>
                        </div>

                        <hr>

                        <button type="submit" class="btn btn-success">
                            💾 Simpan
                        </button>
                        <a href="<?= site_url('buku') ?>" class="btn btn-secondary">
                            Batal
                        </a>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
