<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login | Perpustakaan Sekolah</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">

    <style>
        body {
            background: #f4f6f9;
        }
        .login-box {
            width: 400px;
            margin: 100px auto;
        }
        .card {
            box-shadow: 0 0 10px rgba(0,0,0,.1);
        }
    </style>
</head>
<body>

<div class="login-box">
    <div class="card">
        <div class="card-header text-center">
            <h4><b>Perpustakaan Sekolah</b></h4>
            <small>Silakan Login</small>
        </div>

        <div class="card-body">
            <!-- Pesan Error -->
            <?php if($this->session->flashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= $this->session->flashdata('error'); ?>
                </div>
            <?php endif; ?>

            <form action="<?= base_url('index.php/login/aksi_login') ?>" method="post">
                
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" 
                           class="form-control" 
                           placeholder="Masukkan username" 
                           required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" 
                           class="form-control" 
                           placeholder="Masukkan password" 
                           required>
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    Login
                </button>

            </form>
        </div>

        <div class="card-footer text-center">
            <small>&copy; <?= date('Y') ?> Perpustakaan Sekolah</small>
        </div>
    </div>
</div>

</body>
</html>
