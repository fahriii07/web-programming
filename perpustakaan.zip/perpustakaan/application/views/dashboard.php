<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin | Perpustakaan</title>

    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">

    <style>
        body {
            background-color: #f4f6f9;
        }
        .card-box {
            border-radius: 10px;
        }
        .icon {
            font-size: 40px;
            opacity: 0.7;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?= site_url('dashboard') ?>">
        📚 Perpustakaan
    </a>

    <div class="ml-auto">
        <span class="text-white mr-3">
            Login sebagai: <b><?= $this->session->userdata('username') ?></b>
        </span>
        <a href="<?= site_url('login/logout') ?>" class="btn btn-danger btn-sm">
            Logout
        </a>
    </div>
</nav>

<!-- CONTENT -->
<div class="container mt-4">

    <h4 class="mb-4">Dashboard Admin</h4>

    <!-- STATISTIK -->
    <div class="row">

        <div class="col-md-6">
            <div class="card card-box bg-primary text-white mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5>Jumlah Buku</h5>
                            <h2><?= $jumlah_buku ?></h2>
                        </div>
                        <div class="icon">📖</div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="<?= site_url('buku') ?>" class="text-white">
                        Lihat Data Buku →
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card card-box bg-success text-white mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5>Jumlah User</h5>
                            <h2><?= $jumlah_user ?></h2>
                        </div>
                        <div class="icon">👤</div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="#" class="text-white">
                        Kelola User →
                    </a>
                </div>
            </div>
        </div>

    </div>

    <!-- MENU -->
    <div class="card mt-4">
        <div class="card-header bg-secondary text-white">
            Menu Utama
        </div>
        <div class="card-body">
            <a href="<?= site_url('buku') ?>" class="btn btn-primary mr-2">
                📘 Data Buku
            </a>
           <a href="<?= site_url('transaksi') ?>" class="btn btn-warning">
    🔄 Kelola Transaksi
</a>

            <a href="#" class="btn btn-info">
                👥 Data Anggota
            </a>
        </div>
    </div>

</div>

</body>
</html>
