<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Petugas</title>
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-success">
    <div class="container">
        <span class="navbar-brand">Dashboard Petugas</span>
        <span class="text-white">
            <?= $this->session->userdata('nama') ?> |
            <a href="<?= site_url('login/logout') ?>" class="text-white">Logout</a>
        </span>
    </div>
</nav>

<div class="container mt-4">

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Jumlah Buku</h5>
                    <h2><?= $jumlah_buku ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5>Peminjaman Aktif</h5>
                    <h2><?= $jumlah_pinjam ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-dark text-white">
            Menu Petugas
        </div>
        <div class="card-body">
            <a href="<?= site_url('user/buku') ?>" class="btn btn-primary">📘 Data Buku</a>
            <a href="<?= site_url('user/transaksi') ?>" class="btn btn-success">📄 Transaksi Aktif</a>
        </div>
    </div>

</div>

</body>
</html>
