<!DOCTYPE html>
<html>
<head>
    <title>Data Buku</title>
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h4>Data Buku</h4>

    <table class="table table-bordered">
        <tr>
            <th>Judul</th>
            <th>Pengarang</th>
            <th>Penerbit</th>
            <th>Stok</th>
        </tr>

        <?php foreach($buku as $b): ?>
        <tr>
            <td><?= $b->judul ?></td>
            <td><?= $b->pengarang ?></td>
            <td><?= $b->penerbit ?></td>
            <td><?= $b->stok ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <a href="<?= site_url('user') ?>" class="btn btn-secondary">← Kembali</a>
</div>

</body>
</html>
