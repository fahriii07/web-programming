<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Aktif</title>
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h4>Transaksi Peminjaman Aktif</h4>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Judul Buku</th>
            <th>Tgl Pinjam</th>
        </tr>

        <?php $no=1; foreach($transaksi as $t): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $t->judul ?></td>
            <td><?= $t->tgl_pinjam ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <a href="<?= site_url('user') ?>" class="btn btn-secondary">← Kembali</a>
</div>

</body>
</html>
