<!DOCTYPE html>
<html>
<head>
    <title>Kelola Transaksi</title>
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h4>Kelola Transaksi</h4>

    <table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
    <th>No</th>
    <th>Anggota</th>
    <th>Buku</th>
    <th>Pinjam</th>
    <th>Batas</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</thead>

<tbody>
<?php $no=1; foreach($transaksi as $t): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $t->nama ?></td>
<td><?= $t->judul ?></td>
<td><?= $t->tgl_pinjam ?></td>
<td><?= $t->batas_kembali ?></td>
<td>
<?= $t->status==0
? '<span class="badge bg-warning">Dipinjam</span>'
: '<span class="badge bg-success">Selesai</span>' ?>
</td>
<td>
<?php if($t->status==0): ?>
<a href="<?= site_url('transaksi/konfirmasi/'.$t->id.'/'.$t->id_buku) ?>"
class="btn btn-success btn-sm"
onclick="return confirm('Konfirmasi pengembalian?')">
Kembalikan
</a>
<?php else: ?>
-
<?php endif ?>
</td>
</tr>
<?php endforeach ?>
</tbody>
</table>


    <a href="<?= site_url('dashboard') ?>" class="btn btn-secondary">
        ← Kembali Dashboard
    </a>
</div>

</body>
</html>
