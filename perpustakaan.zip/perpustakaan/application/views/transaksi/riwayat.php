<h4>Riwayat Transaksi</h4>

<table class="table table-bordered">
<tr>
<th>No</th><th>Anggota</th><th>Buku</th>
<th>Pinjam</th><th>Kembali</th><th>Denda</th>
</tr>

<?php $no=1; foreach($transaksi as $t): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $t->id_anggota ?></td>
<td><?= $t->id_buku ?></td>
<td><?= $t->tgl_pinjam ?></td>
<td><?= $t->tgl_kembali ?></td>
<td>Rp <?= number_format($t->denda) ?></td>
</tr>
<?php endforeach ?>
</table>
