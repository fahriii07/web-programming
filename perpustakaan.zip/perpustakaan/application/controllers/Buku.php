<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('login')) {
            redirect('login');
        }
        $this->load->database();
    }

    public function index()
    {
        $data['buku'] = $this->db->get('buku')->result();
        $this->load->view('buku/index', $data);
    }

    public function tambah()
    {
        $this->load->view('buku/tambah');
    }

    public function simpan()
    {
        $data = [
    'judul'     => $this->input->post('judul'),
    'pengarang' => $this->input->post('pengarang'),
    'penerbit'  => $this->input->post('penerbit'),
    'tahun'     => $this->input->post('tahun'),
    'stok'      => $this->input->post('stok')
];

$this->db->insert('buku', $data);
redirect('buku');


        $this->db->insert('buku', $data);
        redirect('buku');
    }

   public function hapus($id)
{
    $this->db->where('id', $id);
    $this->db->delete('buku');
    redirect('buku');
}

}
