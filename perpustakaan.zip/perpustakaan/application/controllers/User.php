<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('login')) {
            redirect('login');
        }

        if ($this->session->userdata('level') != 'petugas') {
            show_error('Akses ditolak');
        }

        $this->load->database();
    }

    public function index()
    {
        // jumlah buku
        $data['jumlah_buku'] = $this->db->count_all('buku');

        // jumlah peminjaman aktif
        $data['jumlah_pinjam'] = $this->db
            ->where('status', 0)
            ->count_all_results('peminjaman');

        $this->load->view('user/dashboard', $data);
    }

    public function buku()
    {
        $data['buku'] = $this->db->get('buku')->result();
        $this->load->view('user/buku', $data);
    }

    public function transaksi()
    {
        $data['transaksi'] = $this->db
            ->select('peminjaman.*, buku.judul')
            ->from('peminjaman')
            ->join('buku','buku.id=peminjaman.id_buku')
            ->where('status',0)
            ->get()->result();

        $this->load->view('user/transaksi', $data);
    }
}
