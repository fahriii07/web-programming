<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->helper(['url','form']);
    }

    // halaman register
    public function index()
    {
        $this->load->view('register');
    }

    // proses simpan register
    public function simpan()
    {
        $nama     = $this->input->post('nama', TRUE);
        $username = $this->input->post('username', TRUE);
        $password = md5($this->input->post('password', TRUE));

        // cek username
        $cek = $this->db->get_where('users', [
            'username' => $username
        ])->num_rows();

        if ($cek > 0) {
            $this->session->set_flashdata(
                'error',
                'Username sudah digunakan!'
            );
            redirect('register');
        }

        // simpan user baru (petugas)
        $this->db->insert('users', [
            'nama'     => $nama,
            'username' => $username,
            'password' => $password,
            'level'    => 'petugas'
        ]);

        $this->session->set_flashdata(
            'success',
            'Registrasi berhasil, silakan login'
        );

        redirect('login');
    }
}
