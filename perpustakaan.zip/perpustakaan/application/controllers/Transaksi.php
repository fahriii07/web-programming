<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('login')) {
            redirect('login');
        }
        $this->load->database();
    }

    public function index()
    {
        $data['transaksi'] = $this->db
            ->select('peminjaman.*, buku.judul, anggota.nama')
            ->from('peminjaman')
            ->join('buku', 'buku.id = peminjaman.id_buku')
            ->join('anggota', 'anggota.id = peminjaman.id_anggota')
            ->get()->result();

        $this->load->view('transaksi/index', $data);
    }

    public function konfirmasi($id, $id_buku)
    {
        $pinjam = $this->db->get_where('peminjaman', ['id'=>$id])->row();

        $today = date('Y-m-d');
        $denda = 0;

        if ($today > $pinjam->batas_kembali) {
            $hari = (strtotime($today) - strtotime($pinjam->batas_kembali)) / 86400;
            $denda = $hari * 1000;
        }

        $this->db->where('id', $id);
        $this->db->update('peminjaman', [
            'tgl_kembali' => $today,
            'status' => 1,
            'denda' => $denda
        ]);

        // kembalikan stok
        $this->db->set('stok', 'stok+1', FALSE);
        $this->db->where('id', $id_buku);
        $this->db->update('buku');

        redirect('transaksi');
    }

    public function riwayat()
    {
        $data['transaksi'] = $this->db
            ->where('status', 1)
            ->get('peminjaman')->result();

        $this->load->view('transaksi/riwayat', $data);
    }
}
