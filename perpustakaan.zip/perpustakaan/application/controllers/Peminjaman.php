class Peminjaman extends CI_Controller {

    public function simpan(){
        $data = [
            'id_buku' => $this->input->post('id_buku'),
            'id_anggota' => $this->input->post('id_anggota'),
            'tanggal_pinjam' => date('Y-m-d'),
            'status' => 'pinjam'
        ];
        $this->db->insert('peminjaman', $data);
        redirect('peminjaman');
    }
}
