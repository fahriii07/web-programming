<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        // Cek login
        if (!$this->session->userdata('login')) {
            redirect('login');
        }

        $this->load->database();
    }

    public function index()
    {
        // Hitung data (opsional, tapi bagus)
        $data['jumlah_buku'] = $this->db->count_all('buku');
        $data['jumlah_user'] = $this->db->count_all('users');

        $this->load->view('dashboard', $data);
    }
}
