<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->helper(['url','form']);
    }

    // =========================
    // HALAMAN LOGIN
    // =========================
    public function index()
    {
        // Jika sudah login, arahkan sesuai level
        if ($this->session->userdata('login') == TRUE) {
            if ($this->session->userdata('level') == 'admin') {
                redirect('dashboard');
            } else {
                redirect('user');
            }
        }

        $this->load->view('login');
    }

    // =========================
    // PROSES LOGIN
    // =========================
    public function aksi_login()
    {
        $username = $this->input->post('username', TRUE);
        $password = md5($this->input->post('password', TRUE));

        // Ambil user dari database
        $user = $this->db->get_where('users', [
            'username' => $username,
            'password' => $password
        ])->row();

        // Jika user ditemukan
        if ($user) {

            // Set session
            $this->session->set_userdata([
                'id'       => $user->id,
                'nama'     => $user->nama,
                'username' => $user->username,
                'level'    => $user->level,
                'login'    => TRUE
            ]);

            // Redirect sesuai role
            if ($user->level == 'admin') {
                redirect('dashboard');
            } else {
                redirect('user');
            }

        } else {
            // Jika gagal login
            $this->session->set_flashdata(
                'error',
                'Username atau password salah!'
            );
            redirect('login');
        }
    }

    // =========================
    // LOGOUT
    // =========================
    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
